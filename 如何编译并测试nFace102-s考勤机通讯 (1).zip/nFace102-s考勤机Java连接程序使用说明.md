# nFace102-s考勤机Java连接程序使用说明

## 项目概述

本项目是基于ZKEMJavaPort的考勤机连接程序，已针对您的nFace102-s考勤机进行了配置。

## 考勤机信息

- **设备型号**: nFace102-s
- **指纹算法**: ZKFingervx10.0
- **平台信息**: ZMM510_TFT
- **固件版本**: ZMM50-NF-Ver1.0.25
- **IP地址**: 192.168.10.180
- **通讯密码**: 202306
- **机号**: 107

## 系统要求

- **操作系统**: Windows (必须)
- **Java版本**: Java 8 或更高版本
- **网络**: 确保计算机与考勤机在同一网络中，能够访问192.168.10.180

## 安装和运行

### 1. 准备工作

1. 确保您的Windows系统已安装Java 8或更高版本
2. 下载编译好的JAR文件：`ZKEM4J-1.0-SNAPSHOT-jar-with-dependencies.jar`

### 2. 运行程序

在命令行中执行：
```bash
java -jar ZKEM4J-1.0-SNAPSHOT-jar-with-dependencies.jar
```

### 3. 可能遇到的问题

#### 问题1：UnsatisfiedLinkError
如果遇到`java.lang.UnsatisfiedLinkError`错误，说明缺少`com4j-amd64.dll`文件。

**解决方案**：
1. 确保`com4j-amd64.dll`文件与JAR文件在同一目录下
2. 或者将DLL文件路径添加到系统PATH环境变量中

#### 问题2：连接失败
如果无法连接到考勤机：

**检查项目**：
1. 确认考勤机IP地址是否为192.168.10.180
2. 确认网络连通性（可以ping 192.168.10.180）
3. 确认考勤机的通讯密码是否为202306
4. 确认考勤机的机号是否为107

## 程序功能

当前测试程序包含以下功能：

1. **连接考勤机**: 自动连接到指定IP的考勤机
2. **读取考勤记录**: 获取考勤机中的打卡记录
3. **显示固件版本**: 显示考勤机的固件版本信息

## 主要类说明

### AttendanceTerminal
考勤机连接和操作的主要类，包含以下方法：
- `connect()`: 连接考勤机
- `disconnect()`: 断开连接
- `readAttendanceRecordsOld()`: 读取考勤记录
- `readEnrolledEmployees()`: 读取已注册员工
- `setUserTemplates()`: 设置用户指纹模板

### Test
测试类，演示如何使用AttendanceTerminal类连接考勤机并读取数据。

## 修改记录

在编译过程中进行了以下修改：

1. **移除icmp4j依赖**: 注释掉了ping相关功能，因为该库在编译时出现问题
2. **移除GUI组件**: 去掉了Swing相关代码，使程序可以在无图形界面环境下运行
3. **更新考勤机配置**: 根据您提供的信息更新了IP地址、密码和机号

## 扩展开发

如果您需要扩展功能，可以参考以下方法：

### 获取考勤数据
```java
AttendanceTerminal terminal = new AttendanceTerminal(107, "nFace102-s", "", "", 1, "zktem", "192.168.10.180", 4370, 202306, 0L);
terminal.connect();
AttendanceRecordsStatement records = terminal.readAttendanceRecordsOld();
for (AttendanceRecord record : records.getRecords()) {
    System.out.println("员工号: " + record.getEmployeeNo() + 
                      " 操作: " + record.getOperation() + 
                      " 时间: " + record.getAttendanceTime());
}
```

### 上传指纹
```java
List<String> templates = new ArrayList<>();
// 添加指纹模板数据
templates.add("指纹模板数据");
terminal.setUserTemplates("员工号", "员工姓名", templates);
```

## 注意事项

1. 本程序仅在Windows环境下测试，Linux环境无法运行
2. 需要确保考勤机与计算机网络连通
3. 考勤机的通讯协议可能因固件版本而异，如遇问题请检查固件兼容性
4. 建议在生产环境使用前进行充分测试

## 技术支持

如果在使用过程中遇到问题，请提供：
1. 详细的错误信息
2. Java版本信息
3. 考勤机的网络连接状态
4. 操作系统版本信息

这将有助于快速定位和解决问题。

