# 新版 Java 中控考勤机 Demo 在 Windows 环境下的运行指南

**作者：** Manus AI  
**日期：** 2025年7月25日  
**版本：** 1.0

## 1. 引言

您好！我已对您提供的 `Java中控考勤机demo.zip` 进行了分析。这个新的 demo 与我们之前处理的 `ZKEMJavaPort-master` 类似，都依赖于 **Jacob (Java COM Bridge)** 技术来调用中控考勤机的 Windows SDK (COM 组件)。因此，它也**必须在 Windows 环境下运行**。

本指南将详细解释为什么会出现 `UnsatisfiedLinkError` 错误，并为您提供在 Windows 环境下正确配置和运行此 demo 的完整步骤，以测试连接您的 nFace102-s 考勤机和 live20r 指纹采集器。

## 2. `UnsatisfiedLinkError` 错误原因及 Windows 环境要求

### 2.1 错误原因

我们遇到的错误是 `java.lang.UnsatisfiedLinkError: no jacob-1.19-x64 in java.library.path`。这个错误的核心原因如下：

*   **Jacob 的工作原理：** Jacob 库包含两部分：一个 Java 的 JAR 包 (`jacob.jar`) 和一个 Windows 的动态链接库 (`.dll` 文件，例如 `jacob-1.19-x64.dll`)。Java 代码通过 `jacob.jar` 调用 `jacob-1.19-x64.dll`，然后这个 DLL 文件再去调用中控的 `zkemkeeper.dll`，从而实现与考勤机的通信。
*   **跨平台不兼容：** `.dll` 文件是 Windows 系统专有的。我们当前的沙盒环境是 Linux 系统，无法加载和执行 `.dll` 文件，因此 Java 虚拟机在尝试加载 `jacob-1.19-x64.dll` 时失败，抛出 `UnsatisfiedLinkError` 错误。

**结论：** 这个 demo 无法在 Linux 环境下运行。您需要在 Windows 电脑上进行后续的测试。

### 2.2 Windows 环境要求

在开始操作之前，请确保您的 Windows 环境满足以下所有条件：

1.  **Windows 操作系统：** 您的电脑必须运行 Windows 操作系统（例如 Windows 7, 8, 10, 11）。
2.  **Java 开发环境 (JDK)：** 确保您的 Windows 系统上已安装 **JDK 8**。此 demo 的 `pom.xml` 文件明确指定了 Java 1.8 版本。
3.  **ZKTeco 官方 Windows SDK：** 您需要从 ZKTeco 官方网站下载并安装针对您考勤机型号的 Windows SDK。这个 SDK 会包含并注册 `zkemkeeper.dll`。
4.  **Jacob DLL 文件：** 您需要将 `jacob-1.19-x64.dll` (如果您使用 64 位 JDK) 或 `jacob-1.19-x86.dll` (如果您使用 32 位 JDK) 放置在 Java 虚拟机可以找到的路径下。

## 3. 在 Windows 环境下运行 demo 的详细步骤

### 3.1 准备工作

1.  **解压 demo：** 将您提供的 `Java中控考勤机demo.zip` 解压到您 Windows 电脑的一个工作目录，例如 `C:\ZKDemo`。
2.  **确认文件结构：** 解压后，您应该会看到 `demo2.rar` 和 `jacob-1.19jar_脱机通讯开发包-6.3.1.-2.rar` 等文件。请将这两个压缩包也解压到当前目录。
    *   解压 `demo2.rar` 后，您会得到一个名为 `demo` 的文件夹，这是主要的 Java 项目。
    *   解压 `jacob-1.19jar_脱机通讯开发包-6.3.1.-2.rar` 后，您会得到 `jacob-1.19` 和 `SDK` 两个文件夹。`jacob-1.19` 文件夹中包含了 `jacob.jar` 和 `jacob-1.19-x64.dll`、`jacob-1.19-x86.dll`。`SDK` 文件夹中包含了 `zkemkeeper.dll`。

### 3.2 配置环境

1.  **注册 `zkemkeeper.dll`：**
    *   根据您的 Windows 系统和 JDK 的位数（32位或64位），选择 `SDK/x86` 或 `SDK/x64` 目录下的 `zkemkeeper.dll`。
    *   以管理员身份运行 `Register_SDK.bat` 或 `Register_SDK x64.bat`，或者手动使用 `regsvr32` 命令注册 `zkemkeeper.dll`。详细步骤请参考我们之前的指南。
2.  **放置 Jacob DLL：**
    *   根据您的 JDK 位数，选择 `jacob-1.19-x64.dll` 或 `jacob-1.19-x86.dll`。
    *   将这个 DLL 文件复制到 **JDK 的 `bin` 目录**下。例如，如果您的 64 位 JDK 安装在 `C:\Program Files\Java\jdk1.8.0_202`，那么就将 `jacob-1.19-x64.dll` 复制到 `C:\Program Files\Java\jdk1.8.0_202\bin` 目录下。这是最简单的方法，可以确保 Java 虚拟机能够找到它。

### 3.3 修改并编译 demo

1.  **修改 `ZkemSDK.java`：**
    *   打开 `C:\ZKDemo\demo\src\main\java\com\example\attendance\ZkemSDK.java` 文件。
    *   找到 `main` 方法，并根据您的考勤机信息修改 `connect` 方法中的 IP 地址和端口号。
        ```java
        public static void main(String[] args) {
            ZkemSDK sdk = new ZkemSDK();
            // 修改为您的 nFace102-s 考勤机 IP
            boolean connFlag = sdk.connect("192.168.10.180", 4370);
            System.out.println("conn:" + connFlag);
            // ...
        }
        ```
2.  **编译项目：**
    *   打开 Windows 命令提示符 (CMD)。
    *   导航到 `demo` 项目的根目录：
        ```cmd
        cd C:\ZKDemo\demo
        ```
    *   运行 Maven 命令进行编译：
        ```cmd
        mvn clean install
        ```
    *   如果编译成功，会在 `target` 目录下生成 `demo2-0.0.1-SNAPSHOT.jar` 文件。

### 3.4 运行测试程序

1.  **测试 nFace102-s 考勤机：**
    *   在命令提示符中，运行以下命令：
        ```cmd
        java -cp target/demo2-0.0.1-SNAPSHOT.jar;src/main/resources/lib/jacob.jar com.example.attendance.ZkemSDK
        ```
    *   观察控制台输出，查看连接是否成功，以及是否能获取到用户信息和考勤记录。

2.  **测试 live20r 指纹采集器：**
    *   **重要：** live20r 指纹采集器通常是连接到电脑的 USB 设备，而不是通过网络连接。这个 demo 是为网络连接的考勤机设计的，可能无法直接连接 live20r。您需要使用 ZKTeco 提供的专门针对 USB 指纹采集器的 SDK 和 demo。
    *   如果您的 live20r 确实是通过网络连接的，请修改 `ZkemSDK.java` 中的 IP 地址为 live20r 的 IP，然后重新编译并运行。

### 3.5 常见问题排查

*   **`UnsatisfiedLinkError`：** 确保 `jacob-1.19-x64.dll` 或 `jacob-1.19-x86.dll` 已被复制到正确的 JDK `bin` 目录下，并且位数与 JDK 一致。
*   **连接失败：** 检查考勤机 IP、端口、网络连接、防火墙设置，以及 `zkemkeeper.dll` 是否已正确注册。
*   **`ClassNotFoundException`：** 检查 `java -cp` 命令中的 classpath 设置是否正确，确保包含了 `demo2-0.0.1-SNAPSHOT.jar` 和 `jacob.jar`。

## 4. 总结

这个新的 demo 为我们提供了更清晰的连接逻辑和更完整的 SDK 文件。请您务必在 Windows 环境下，按照本指南的步骤进行操作。核心是正确配置 `zkemkeeper.dll` 和 `jacob` 的 DLL 文件。祝您测试成功！

