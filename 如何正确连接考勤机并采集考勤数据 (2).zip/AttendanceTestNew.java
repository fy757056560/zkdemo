package ps.purelogic.zkem4j;

import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.List;

/**
 * 考勤机测试类 - 支持多种输出格式
 * 
 * 使用方法：
 * java AttendanceTestNew [输出格式]
 * 
 * 输出格式选项：
 * - console (默认): 控制台输出
 * - txt: 输出到TXT文件
 * - excel: 输出到Excel文件
 * - all: 输出到所有格式
 */
public class AttendanceTestNew {
    
    private AttendanceTerminal aTerminal;
    private String deviceName = "nFace102-s";
    
    public AttendanceTestNew() {
        prepare();
    }
    
    private void prepare() {
        System.out.println("=== 考勤机连接测试 ===");
        System.out.println("设备型号: " + deviceName);
        System.out.println("指纹算法: ZKFingervx10.0");
        System.out.println("平台信息: ZMM510_TFT");
        System.out.println("固件版本: ZMM50-NF-Ver1.0.25");
        System.out.println("IP地址: 192.168.10.180");
        System.out.println("通讯密码: 202306");
        System.out.println("机号: 107");
        System.out.println();
        
        // 创建考勤机连接
        aTerminal = new AttendanceTerminal(
            107,                    // 机号
            deviceName,             // 设备名称
            "B",                   // 区块号
            "Base",                // 区块名称
            1,                     // 品牌ID
            "ZKTeco",              // 品牌名称
            "192.168.10.180",      // IP地址
            4370,                  // 端口号
            202306,                // 通讯密码
            0L                     // 最后读取时间戳
        );
    }
    
    public void runTest(String outputFormat) {
        try {
            System.out.println("正在连接考勤机...");
            
            // 连接考勤机
            aTerminal.connect();
            System.out.println("考勤机连接成功！");
            
            // 获取员工信息
            System.out.println("获取员工信息...");
            List<EnrolledEmployee> employees = aTerminal.readEnrolledEmployees();
            
            // 获取考勤数据（使用智能方法，自动检测TFT类型）
            System.out.println("获取考勤数据...");
            AttendanceRecordsStatement records = aTerminal.readAttendanceRecordsSmart();
            
            // 根据输出格式进行输出
            exportData(employees, records, outputFormat);
            
            // 断开连接
            aTerminal.disconnect();
            System.out.println("考勤机连接已断开");
            
        } catch (Exception e) {
            System.err.println("测试过程中发生错误: " + e.getMessage());
            e.printStackTrace();
        }
    }
    
    private void exportData(List<EnrolledEmployee> employees, AttendanceRecordsStatement records, String outputFormat) {
        try {
            String timestamp = new SimpleDateFormat("yyyyMMdd_HHmmss").format(new Date());
            
            switch (outputFormat.toLowerCase()) {
                case "console":
                    AttendanceDataExporter.exportToConsole(employees, records, deviceName);
                    break;
                    
                case "txt":
                    String txtFile = "考勤数据_" + timestamp + ".txt";
                    AttendanceDataExporter.exportToTxt(employees, records, deviceName, txtFile);
                    break;
                    
                case "excel":
                    String excelFile = "考勤数据_" + timestamp + ".xlsx";
                    AttendanceDataExporter.exportToExcel(employees, records, deviceName, excelFile);
                    break;
                    
                case "all":
                    // 输出到所有格式
                    AttendanceDataExporter.exportToConsole(employees, records, deviceName);
                    
                    String txtFileAll = "考勤数据_" + timestamp + ".txt";
                    AttendanceDataExporter.exportToTxt(employees, records, deviceName, txtFileAll);
                    
                    String excelFileAll = "考勤数据_" + timestamp + ".xlsx";
                    AttendanceDataExporter.exportToExcel(employees, records, deviceName, excelFileAll);
                    break;
                    
                default:
                    System.out.println("未知的输出格式: " + outputFormat + "，使用默认控制台输出");
                    AttendanceDataExporter.exportToConsole(employees, records, deviceName);
                    break;
            }
            
        } catch (Exception e) {
            System.err.println("数据导出时发生错误: " + e.getMessage());
            e.printStackTrace();
        }
    }
    
    public static void main(String[] args) {
        System.out.println("考勤机数据采集程序启动...");
        System.out.println("程序版本: 2.0 (修复TFT设备API问题，支持多种输出格式)");
        System.out.println();
        
        // 获取输出格式参数
        String outputFormat = "console"; // 默认控制台输出
        if (args.length > 0) {
            outputFormat = args[0];
        }
        
        System.out.println("输出格式: " + outputFormat);
        System.out.println("支持的格式: console, txt, excel, all");
        System.out.println();
        
        // 运行测试
        AttendanceTestNew test = new AttendanceTestNew();
        test.runTest(outputFormat);
        
        System.out.println("\n程序执行完成！");
        
        // 显示使用说明
        if ("console".equals(outputFormat)) {
            System.out.println("\n使用说明:");
            System.out.println("- 输出到TXT文件: java AttendanceTestNew txt");
            System.out.println("- 输出到Excel文件: java AttendanceTestNew excel");
            System.out.println("- 输出到所有格式: java AttendanceTestNew all");
        }
    }
}

