package ps.purelogic.zkem4j;

import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Date;
import java.util.List;

/**
 * 考勤机简单测试类 - 用于验证程序逻辑
 * 不需要实际连接考勤机，使用模拟数据测试输出功能
 */
public class AttendanceTestSimple {
    
    private String deviceName = "nFace102-s";
    
    public void runTest(String outputFormat) {
        System.out.println("=== 考勤机程序逻辑测试 ===");
        System.out.println("设备型号: " + deviceName);
        System.out.println("测试模式: 模拟数据测试");
        System.out.println();
        
        try {
            // 创建模拟员工数据
            List<EnrolledEmployee> employees = createMockEmployees();
            System.out.println("模拟员工数据创建成功，共 " + employees.size() + " 人");
            
            // 创建模拟考勤数据
            AttendanceRecordsStatement records = createMockAttendanceRecords();
            System.out.println("模拟考勤数据创建成功，共 " + records.getRecords().size() + " 条记录");
            System.out.println();
            
            // 根据输出格式进行输出
            exportData(employees, records, outputFormat);
            
            System.out.println("测试完成！");
            
        } catch (Exception e) {
            System.err.println("测试过程中发生错误: " + e.getMessage());
            e.printStackTrace();
        }
    }
    
    private List<EnrolledEmployee> createMockEmployees() {
        List<EnrolledEmployee> employees = new ArrayList<>();
        
        // 创建一些模拟员工
        employees.add(new EnrolledEmployee("304837", "胡颂云", "", 1, 107, true));
        employees.add(new EnrolledEmployee("304843", "李雪峰", "", 1, 107, true));
        employees.add(new EnrolledEmployee("304856", "张三", "", 1, 107, true));
        employees.add(new EnrolledEmployee("304867", "李四", "", 1, 107, true));
        employees.add(new EnrolledEmployee("304878", "王五", "", 1, 107, true));
        
        return employees;
    }
    
    private AttendanceRecordsStatement createMockAttendanceRecords() {
        List<AttendanceRecord> records = new ArrayList<>();
        
        // 创建一些模拟考勤记录
        SimpleDateFormat sdf = new SimpleDateFormat("yyyy-MM-dd HH:mm:ss");
        
        try {
            records.add(new AttendanceRecord(107, "304837", AttendanceOperation.IN, 
                sdf.parse("2025-08-04 08:30:15").getTime(), System.currentTimeMillis()));
            records.add(new AttendanceRecord(107, "304843", AttendanceOperation.IN, 
                sdf.parse("2025-08-04 08:35:22").getTime(), System.currentTimeMillis()));
            records.add(new AttendanceRecord(107, "304856", AttendanceOperation.IN, 
                sdf.parse("2025-08-04 08:45:10").getTime(), System.currentTimeMillis()));
            records.add(new AttendanceRecord(107, "304837", AttendanceOperation.OUT, 
                sdf.parse("2025-08-04 12:00:30").getTime(), System.currentTimeMillis()));
            records.add(new AttendanceRecord(107, "304843", AttendanceOperation.IN, 
                sdf.parse("2025-08-04 13:15:45").getTime(), System.currentTimeMillis()));
            records.add(new AttendanceRecord(107, "304867", AttendanceOperation.IN, 
                sdf.parse("2025-08-04 09:10:20").getTime(), System.currentTimeMillis()));
            records.add(new AttendanceRecord(107, "304878", AttendanceOperation.IN, 
                sdf.parse("2025-08-04 08:55:33").getTime(), System.currentTimeMillis()));
            records.add(new AttendanceRecord(107, "304856", AttendanceOperation.OUT, 
                sdf.parse("2025-08-04 17:30:15").getTime(), System.currentTimeMillis()));
            
        } catch (Exception e) {
            System.err.println("创建模拟数据时发生错误: " + e.getMessage());
        }
        
        return new AttendanceRecordsStatement(107, System.currentTimeMillis(), System.currentTimeMillis(), records);
    }
    
    private void exportData(List<EnrolledEmployee> employees, AttendanceRecordsStatement records, String outputFormat) {
        try {
            String timestamp = new SimpleDateFormat("yyyyMMdd_HHmmss").format(new Date());
            
            switch (outputFormat.toLowerCase()) {
                case "console":
                    AttendanceDataExporter.exportToConsole(employees, records, deviceName);
                    break;
                    
                case "txt":
                    String txtFile = "考勤数据_测试_" + timestamp + ".txt";
                    AttendanceDataExporter.exportToTxt(employees, records, deviceName, txtFile);
                    System.out.println("TXT文件已生成: " + txtFile);
                    break;
                    
                case "excel":
                    String excelFile = "考勤数据_测试_" + timestamp + ".xlsx";
                    AttendanceDataExporter.exportToExcel(employees, records, deviceName, excelFile);
                    System.out.println("Excel文件已生成: " + excelFile);
                    break;
                    
                case "all":
                    // 输出到所有格式
                    AttendanceDataExporter.exportToConsole(employees, records, deviceName);
                    
                    String txtFileAll = "考勤数据_测试_" + timestamp + ".txt";
                    AttendanceDataExporter.exportToTxt(employees, records, deviceName, txtFileAll);
                    System.out.println("TXT文件已生成: " + txtFileAll);
                    
                    String excelFileAll = "考勤数据_测试_" + timestamp + ".xlsx";
                    AttendanceDataExporter.exportToExcel(employees, records, deviceName, excelFileAll);
                    System.out.println("Excel文件已生成: " + excelFileAll);
                    break;
                    
                default:
                    System.out.println("未知的输出格式: " + outputFormat + "，使用默认控制台输出");
                    AttendanceDataExporter.exportToConsole(employees, records, deviceName);
                    break;
            }
            
        } catch (Exception e) {
            System.err.println("数据导出时发生错误: " + e.getMessage());
            e.printStackTrace();
        }
    }
    
    public static void main(String[] args) {
        System.out.println("考勤机程序逻辑测试启动...");
        System.out.println("程序版本: 2.0 (修复TFT设备API问题，支持多种输出格式)");
        System.out.println("测试模式: 使用模拟数据，不需要实际考勤机连接");
        System.out.println();
        
        // 获取输出格式参数
        String outputFormat = "console"; // 默认控制台输出
        if (args.length > 0) {
            outputFormat = args[0];
        }
        
        System.out.println("输出格式: " + outputFormat);
        System.out.println("支持的格式: console, txt, excel, all");
        System.out.println();
        
        // 运行测试
        AttendanceTestSimple test = new AttendanceTestSimple();
        test.runTest(outputFormat);
        
        System.out.println("\n程序执行完成！");
        
        // 显示使用说明
        if ("console".equals(outputFormat)) {
            System.out.println("\n使用说明:");
            System.out.println("- 输出到TXT文件: java AttendanceTestSimple txt");
            System.out.println("- 输出到Excel文件: java AttendanceTestSimple excel");
            System.out.println("- 输出到所有格式: java AttendanceTestSimple all");
            System.out.println("\n注意: 这是逻辑测试版本，使用模拟数据");
            System.out.println("实际使用时请运行 AttendanceTestNew 连接真实考勤机");
        }
    }
}

