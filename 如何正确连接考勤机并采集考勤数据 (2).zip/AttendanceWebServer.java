package ps.purelogic.zkem4j.web;

import com.sun.net.httpserver.HttpExchange;
import com.sun.net.httpserver.HttpHandler;
import com.sun.net.httpserver.HttpServer;

import java.io.*;
import java.net.InetSocketAddress;
import java.net.URLDecoder;
import java.nio.charset.StandardCharsets;
import java.util.HashMap;
import java.util.Map;

/**
 * 考勤机Web服务器
 * 提供HTTP接口供前端调用
 */
public class AttendanceWebServer {
    
    private HttpServer server;
    private AttendanceWebControllerSimple controller;
    private int port = 8080;
    
    public AttendanceWebServer() {
        this.controller = new AttendanceWebControllerSimple();
    }
    
    public AttendanceWebServer(int port) {
        this.port = port;
        this.controller = new AttendanceWebControllerSimple();
    }
    
    /**
     * 启动Web服务器
     */
    public void start() throws IOException {
        server = HttpServer.create(new InetSocketAddress(port), 0);
        
        // 设置路由
        server.createContext("/", new StaticFileHandler());
        server.createContext("/api/status", new StatusHandler());
        server.createContext("/api/test", new TestConnectionHandler());
        server.createContext("/api/employees", new EmployeesHandler());
        server.createContext("/api/attendance", new AttendanceHandler());
        server.createContext("/api/export", new ExportHandler());
        
        server.setExecutor(null);
        server.start();
        
        System.out.println("考勤机Web服务器已启动");
        System.out.println("访问地址: http://localhost:" + port);
        System.out.println("API文档:");
        System.out.println("  GET  /api/status     - 获取系统状态");
        System.out.println("  POST /api/test       - 测试考勤机连接");
        System.out.println("  GET  /api/employees  - 获取员工信息");
        System.out.println("  GET  /api/attendance - 获取考勤数据");
        System.out.println("  POST /api/export     - 导出数据 (参数: format=txt|excel)");
    }
    
    /**
     * 停止Web服务器
     */
    public void stop() {
        if (server != null) {
            server.stop(0);
            System.out.println("考勤机Web服务器已停止");
        }
    }
    
    /**
     * 静态文件处理器
     */
    class StaticFileHandler implements HttpHandler {
        @Override
        public void handle(HttpExchange exchange) throws IOException {
            String response = getIndexHtml();
            exchange.getResponseHeaders().set("Content-Type", "text/html; charset=UTF-8");
            exchange.sendResponseHeaders(200, response.getBytes(StandardCharsets.UTF_8).length);
            OutputStream os = exchange.getResponseBody();
            os.write(response.getBytes(StandardCharsets.UTF_8));
            os.close();
        }
    }
    
    /**
     * 系统状态处理器
     */
    class StatusHandler implements HttpHandler {
        @Override
        public void handle(HttpExchange exchange) throws IOException {
            Map<String, Object> result = controller.getSystemStatus();
            sendJsonResponse(exchange, result);
        }
    }
    
    /**
     * 测试连接处理器
     */
    class TestConnectionHandler implements HttpHandler {
        @Override
        public void handle(HttpExchange exchange) throws IOException {
            if ("POST".equals(exchange.getRequestMethod())) {
                Map<String, Object> result = controller.testConnection();
                sendJsonResponse(exchange, result);
            } else {
                sendErrorResponse(exchange, 405, "Method Not Allowed");
            }
        }
    }
    
    /**
     * 员工信息处理器
     */
    class EmployeesHandler implements HttpHandler {
        @Override
        public void handle(HttpExchange exchange) throws IOException {
            if ("GET".equals(exchange.getRequestMethod())) {
                Map<String, Object> result = controller.getEmployees();
                sendJsonResponse(exchange, result);
            } else {
                sendErrorResponse(exchange, 405, "Method Not Allowed");
            }
        }
    }
    
    /**
     * 考勤数据处理器
     */
    class AttendanceHandler implements HttpHandler {
        @Override
        public void handle(HttpExchange exchange) throws IOException {
            if ("GET".equals(exchange.getRequestMethod())) {
                Map<String, Object> result = controller.getAttendanceRecords();
                sendJsonResponse(exchange, result);
            } else {
                sendErrorResponse(exchange, 405, "Method Not Allowed");
            }
        }
    }
    
    /**
     * 数据导出处理器
     */
    class ExportHandler implements HttpHandler {
        @Override
        public void handle(HttpExchange exchange) throws IOException {
            if ("POST".equals(exchange.getRequestMethod())) {
                // 解析请求参数
                String requestBody = readRequestBody(exchange);
                Map<String, String> params = parseFormData(requestBody);
                String format = params.getOrDefault("format", "txt");
                
                Map<String, Object> result = controller.exportData(format);
                sendJsonResponse(exchange, result);
            } else {
                sendErrorResponse(exchange, 405, "Method Not Allowed");
            }
        }
    }
    
    /**
     * 发送JSON响应
     */
    private void sendJsonResponse(HttpExchange exchange, Map<String, Object> data) throws IOException {
        String json = mapToJson(data);
        exchange.getResponseHeaders().set("Content-Type", "application/json; charset=UTF-8");
        exchange.getResponseHeaders().set("Access-Control-Allow-Origin", "*");
        exchange.sendResponseHeaders(200, json.getBytes(StandardCharsets.UTF_8).length);
        OutputStream os = exchange.getResponseBody();
        os.write(json.getBytes(StandardCharsets.UTF_8));
        os.close();
    }
    
    /**
     * 发送错误响应
     */
    private void sendErrorResponse(HttpExchange exchange, int code, String message) throws IOException {
        exchange.getResponseHeaders().set("Content-Type", "text/plain; charset=UTF-8");
        exchange.sendResponseHeaders(code, message.getBytes(StandardCharsets.UTF_8).length);
        OutputStream os = exchange.getResponseBody();
        os.write(message.getBytes(StandardCharsets.UTF_8));
        os.close();
    }
    
    /**
     * 读取请求体
     */
    private String readRequestBody(HttpExchange exchange) throws IOException {
        InputStream is = exchange.getRequestBody();
        BufferedReader reader = new BufferedReader(new InputStreamReader(is, StandardCharsets.UTF_8));
        StringBuilder sb = new StringBuilder();
        String line;
        while ((line = reader.readLine()) != null) {
            sb.append(line);
        }
        return sb.toString();
    }
    
    /**
     * 解析表单数据
     */
    private Map<String, String> parseFormData(String formData) {
        Map<String, String> params = new HashMap<>();
        if (formData != null && !formData.isEmpty()) {
            String[] pairs = formData.split("&");
            for (String pair : pairs) {
                String[] keyValue = pair.split("=");
                if (keyValue.length == 2) {
                    try {
                        String key = URLDecoder.decode(keyValue[0], "UTF-8");
                        String value = URLDecoder.decode(keyValue[1], "UTF-8");
                        params.put(key, value);
                    } catch (UnsupportedEncodingException e) {
                        // 忽略解码错误
                    }
                }
            }
        }
        return params;
    }
    
    /**
     * 简单的Map转JSON
     */
    private String mapToJson(Map<String, Object> map) {
        StringBuilder json = new StringBuilder();
        json.append("{");
        boolean first = true;
        for (Map.Entry<String, Object> entry : map.entrySet()) {
            if (!first) {
                json.append(",");
            }
            json.append("\"").append(entry.getKey()).append("\":");
            Object value = entry.getValue();
            if (value == null) {
                json.append("null");
            } else if (value instanceof String) {
                json.append("\"").append(value.toString().replace("\"", "\\\"")).append("\"");
            } else if (value instanceof Number || value instanceof Boolean) {
                json.append(value.toString());
            } else {
                json.append("\"").append(value.toString().replace("\"", "\\\"")).append("\"");
            }
            first = false;
        }
        json.append("}");
        return json.toString();
    }
    
    /**
     * 获取首页HTML
     */
    private String getIndexHtml() {
        return "<!DOCTYPE html>\n" +
                "<html lang=\"zh-CN\">\n" +
                "<head>\n" +
                "    <meta charset=\"UTF-8\">\n" +
                "    <meta name=\"viewport\" content=\"width=device-width, initial-scale=1.0\">\n" +
                "    <title>考勤机数据采集系统</title>\n" +
                "    <style>\n" +
                "        body { font-family: Arial, sans-serif; margin: 20px; background-color: #f5f5f5; }\n" +
                "        .container { max-width: 1200px; margin: 0 auto; background: white; padding: 20px; border-radius: 8px; box-shadow: 0 2px 4px rgba(0,0,0,0.1); }\n" +
                "        h1 { color: #333; text-align: center; }\n" +
                "        .section { margin: 20px 0; padding: 15px; border: 1px solid #ddd; border-radius: 5px; }\n" +
                "        .button { background: #007cba; color: white; padding: 10px 20px; border: none; border-radius: 4px; cursor: pointer; margin: 5px; }\n" +
                "        .button:hover { background: #005a87; }\n" +
                "        .result { margin-top: 10px; padding: 10px; background: #f9f9f9; border-radius: 4px; white-space: pre-wrap; }\n" +
                "        .success { border-left: 4px solid #4caf50; }\n" +
                "        .error { border-left: 4px solid #f44336; }\n" +
                "        .info { border-left: 4px solid #2196f3; }\n" +
                "    </style>\n" +
                "</head>\n" +
                "<body>\n" +
                "    <div class=\"container\">\n" +
                "        <h1>考勤机数据采集系统</h1>\n" +
                "        \n" +
                "        <div class=\"section\">\n" +
                "            <h3>系统状态</h3>\n" +
                "            <button class=\"button\" onclick=\"getStatus()\">获取系统状态</button>\n" +
                "            <div id=\"statusResult\" class=\"result\"></div>\n" +
                "        </div>\n" +
                "        \n" +
                "        <div class=\"section\">\n" +
                "            <h3>连接测试</h3>\n" +
                "            <button class=\"button\" onclick=\"testConnection()\">测试考勤机连接</button>\n" +
                "            <div id=\"testResult\" class=\"result\"></div>\n" +
                "        </div>\n" +
                "        \n" +
                "        <div class=\"section\">\n" +
                "            <h3>数据获取</h3>\n" +
                "            <button class=\"button\" onclick=\"getEmployees()\">获取员工信息</button>\n" +
                "            <button class=\"button\" onclick=\"getAttendance()\">获取考勤数据</button>\n" +
                "            <div id=\"dataResult\" class=\"result\"></div>\n" +
                "        </div>\n" +
                "        \n" +
                "        <div class=\"section\">\n" +
                "            <h3>数据导出</h3>\n" +
                "            <button class=\"button\" onclick=\"exportData('txt')\">导出为TXT</button>\n" +
                "            <button class=\"button\" onclick=\"exportData('excel')\">导出为Excel</button>\n" +
                "            <div id=\"exportResult\" class=\"result\"></div>\n" +
                "        </div>\n" +
                "    </div>\n" +
                "    \n" +
                "    <script>\n" +
                "        function getStatus() {\n" +
                "            fetch('/api/status')\n" +
                "                .then(response => response.json())\n" +
                "                .then(data => {\n" +
                "                    document.getElementById('statusResult').innerHTML = JSON.stringify(data, null, 2);\n" +
                "                    document.getElementById('statusResult').className = 'result ' + (data.success ? 'success' : 'error');\n" +
                "                })\n" +
                "                .catch(error => {\n" +
                "                    document.getElementById('statusResult').innerHTML = '错误: ' + error;\n" +
                "                    document.getElementById('statusResult').className = 'result error';\n" +
                "                });\n" +
                "        }\n" +
                "        \n" +
                "        function testConnection() {\n" +
                "            fetch('/api/test', { method: 'POST' })\n" +
                "                .then(response => response.json())\n" +
                "                .then(data => {\n" +
                "                    document.getElementById('testResult').innerHTML = JSON.stringify(data, null, 2);\n" +
                "                    document.getElementById('testResult').className = 'result ' + (data.success ? 'success' : 'error');\n" +
                "                })\n" +
                "                .catch(error => {\n" +
                "                    document.getElementById('testResult').innerHTML = '错误: ' + error;\n" +
                "                    document.getElementById('testResult').className = 'result error';\n" +
                "                });\n" +
                "        }\n" +
                "        \n" +
                "        function getEmployees() {\n" +
                "            fetch('/api/employees')\n" +
                "                .then(response => response.json())\n" +
                "                .then(data => {\n" +
                "                    document.getElementById('dataResult').innerHTML = JSON.stringify(data, null, 2);\n" +
                "                    document.getElementById('dataResult').className = 'result ' + (data.success ? 'success' : 'error');\n" +
                "                })\n" +
                "                .catch(error => {\n" +
                "                    document.getElementById('dataResult').innerHTML = '错误: ' + error;\n" +
                "                    document.getElementById('dataResult').className = 'result error';\n" +
                "                });\n" +
                "        }\n" +
                "        \n" +
                "        function getAttendance() {\n" +
                "            fetch('/api/attendance')\n" +
                "                .then(response => response.json())\n" +
                "                .then(data => {\n" +
                "                    document.getElementById('dataResult').innerHTML = JSON.stringify(data, null, 2);\n" +
                "                    document.getElementById('dataResult').className = 'result ' + (data.success ? 'success' : 'error');\n" +
                "                })\n" +
                "                .catch(error => {\n" +
                "                    document.getElementById('dataResult').innerHTML = '错误: ' + error;\n" +
                "                    document.getElementById('dataResult').className = 'result error';\n" +
                "                });\n" +
                "        }\n" +
                "        \n" +
                "        function exportData(format) {\n" +
                "            fetch('/api/export', {\n" +
                "                method: 'POST',\n" +
                "                headers: { 'Content-Type': 'application/x-www-form-urlencoded' },\n" +
                "                body: 'format=' + format\n" +
                "            })\n" +
                "                .then(response => response.json())\n" +
                "                .then(data => {\n" +
                "                    document.getElementById('exportResult').innerHTML = JSON.stringify(data, null, 2);\n" +
                "                    document.getElementById('exportResult').className = 'result ' + (data.success ? 'success' : 'error');\n" +
                "                })\n" +
                "                .catch(error => {\n" +
                "                    document.getElementById('exportResult').innerHTML = '错误: ' + error;\n" +
                "                    document.getElementById('exportResult').className = 'result error';\n" +
                "                });\n" +
                "        }\n" +
                "        \n" +
                "        // 页面加载时自动获取状态\n" +
                "        window.onload = function() {\n" +
                "            getStatus();\n" +
                "        };\n" +
                "    </script>\n" +
                "</body>\n" +
                "</html>";
    }
    
    /**
     * 主方法 - 启动Web服务器
     */
    public static void main(String[] args) {
        try {
            int port = 8080;
            if (args.length > 0) {
                try {
                    port = Integer.parseInt(args[0]);
                } catch (NumberFormatException e) {
                    System.out.println("无效的端口号，使用默认端口8080");
                }
            }
            
            AttendanceWebServer server = new AttendanceWebServer(port);
            server.start();
            
            // 添加关闭钩子
            Runtime.getRuntime().addShutdownHook(new Thread(server::stop));
            
            System.out.println("按 Ctrl+C 停止服务器");
            
            // 保持程序运行
            Thread.currentThread().join();
            
        } catch (Exception e) {
            System.err.println("启动Web服务器失败: " + e.getMessage());
            e.printStackTrace();
        }
    }
}

