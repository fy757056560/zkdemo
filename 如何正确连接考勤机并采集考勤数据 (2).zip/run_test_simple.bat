@echo off
echo 考勤机程序测试 - 基础功能验证
echo =====================================
echo.

REM 检查Java环境
java -version >nul 2>&1
if %errorlevel% neq 0 (
    echo 错误: 未找到Java运行环境，请先安装Java 8或更高版本
    pause
    exit /b 1
)

echo 运行程序逻辑测试（使用模拟数据）...
echo.

REM 运行简单测试版本
cd target
java -cp "classes;dependency/*" ps.purelogic.zkem4j.AttendanceTestSimple console

echo.
echo 测试完成！
echo.
echo 其他测试选项:
echo   java -cp "classes;dependency/*" ps.purelogic.zkem4j.AttendanceTestSimple txt
echo   java -cp "classes;dependency/*" ps.purelogic.zkem4j.AttendanceTestSimple excel
echo   java -cp "classes;dependency/*" ps.purelogic.zkem4j.AttendanceTestSimple all
echo.
echo 注意: 这是逻辑测试版本，使用模拟数据
echo 实际连接考勤机请使用: java -jar ZKEM4J-1.0-SNAPSHOT.jar
echo （需要在Windows环境中运行）
echo.
pause

