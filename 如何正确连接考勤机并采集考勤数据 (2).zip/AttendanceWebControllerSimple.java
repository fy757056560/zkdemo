package ps.purelogic.zkem4j.web;

import ps.purelogic.zkem4j.*;

import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Date;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

/**
 * 考勤机Web控制器 - 简单版本
 * 使用模拟数据，不需要实际连接考勤机
 */
public class AttendanceWebControllerSimple {
    
    private String deviceName = "nFace102-s";
    
    /**
     * 获取系统状态
     */
    public Map<String, Object> getSystemStatus() {
        Map<String, Object> result = new HashMap<>();
        
        try {
            result.put("success", true);
            result.put("message", "系统状态正常（模拟模式）");
            result.put("timestamp", new SimpleDateFormat("yyyy-MM-dd HH:mm:ss").format(new Date()));
            result.put("deviceInfo", getDeviceInfo());
            result.put("mode", "simulation");
            result.put("note", "当前运行在模拟模式，使用测试数据");
            
        } catch (Exception e) {
            result.put("success", false);
            result.put("message", "获取系统状态失败: " + e.getMessage());
        }
        
        return result;
    }
    
    /**
     * 测试考勤机连接
     */
    public Map<String, Object> testConnection() {
        Map<String, Object> result = new HashMap<>();
        
        try {
            // 模拟连接测试
            Thread.sleep(1000); // 模拟连接延迟
            
            result.put("success", true);
            result.put("message", "考勤机连接测试成功（模拟模式）");
            result.put("deviceInfo", getDeviceInfo());
            result.put("connectionTime", new SimpleDateFormat("yyyy-MM-dd HH:mm:ss").format(new Date()));
            result.put("note", "这是模拟连接测试，实际部署时会连接真实设备");
            
        } catch (Exception e) {
            result.put("success", false);
            result.put("message", "考勤机连接测试失败: " + e.getMessage());
        }
        
        return result;
    }
    
    /**
     * 获取员工信息
     */
    public Map<String, Object> getEmployees() {
        Map<String, Object> result = new HashMap<>();
        
        try {
            List<EnrolledEmployee> employees = createMockEmployees();
            
            result.put("success", true);
            result.put("message", "员工信息获取成功（模拟数据）");
            result.put("employees", employees);
            result.put("count", employees.size());
            result.put("timestamp", new SimpleDateFormat("yyyy-MM-dd HH:mm:ss").format(new Date()));
            result.put("note", "这是模拟员工数据，实际部署时会从考勤机获取");
            
        } catch (Exception e) {
            result.put("success", false);
            result.put("message", "员工信息获取失败: " + e.getMessage());
        }
        
        return result;
    }
    
    /**
     * 获取考勤数据
     */
    public Map<String, Object> getAttendanceRecords() {
        Map<String, Object> result = new HashMap<>();
        
        try {
            // 获取模拟数据
            List<EnrolledEmployee> employees = createMockEmployees();
            AttendanceRecordsStatement records = createMockAttendanceRecords();
            
            result.put("success", true);
            result.put("message", "考勤数据获取成功（模拟数据）");
            result.put("employees", employees);
            result.put("records", records.getRecords());
            result.put("employeeCount", employees.size());
            result.put("recordCount", records.getRecords().size());
            result.put("timestamp", new SimpleDateFormat("yyyy-MM-dd HH:mm:ss").format(new Date()));
            result.put("note", "这是模拟考勤数据，实际部署时会从考勤机获取");
            
        } catch (Exception e) {
            result.put("success", false);
            result.put("message", "考勤数据获取失败: " + e.getMessage());
        }
        
        return result;
    }
    
    /**
     * 导出数据到文件
     */
    public Map<String, Object> exportData(String format) {
        Map<String, Object> result = new HashMap<>();
        
        try {
            // 获取模拟数据
            List<EnrolledEmployee> employees = createMockEmployees();
            AttendanceRecordsStatement records = createMockAttendanceRecords();
            
            // 生成文件名
            String timestamp = new SimpleDateFormat("yyyyMMdd_HHmmss").format(new Date());
            String fileName = "";
            
            // 根据格式导出
            switch (format.toLowerCase()) {
                case "txt":
                    fileName = "考勤数据_Web导出_" + timestamp + ".txt";
                    AttendanceDataExporter.exportToTxt(employees, records, deviceName, fileName);
                    break;
                    
                case "excel":
                    fileName = "考勤数据_Web导出_" + timestamp + ".xlsx";
                    AttendanceDataExporter.exportToExcel(employees, records, deviceName, fileName);
                    break;
                    
                default:
                    throw new IllegalArgumentException("不支持的导出格式: " + format);
            }
            
            result.put("success", true);
            result.put("message", "数据导出成功（模拟数据）");
            result.put("fileName", fileName);
            result.put("format", format);
            result.put("timestamp", new SimpleDateFormat("yyyy-MM-dd HH:mm:ss").format(new Date()));
            result.put("note", "文件已保存到服务器目录，实际部署时可提供下载链接");
            
        } catch (Exception e) {
            result.put("success", false);
            result.put("message", "数据导出失败: " + e.getMessage());
        }
        
        return result;
    }
    
    /**
     * 创建模拟员工数据
     */
    private List<EnrolledEmployee> createMockEmployees() {
        List<EnrolledEmployee> employees = new ArrayList<>();
        
        employees.add(new EnrolledEmployee("304837", "胡颂云", "", 1, 107, true));
        employees.add(new EnrolledEmployee("304843", "李雪峰", "", 1, 107, true));
        employees.add(new EnrolledEmployee("304856", "张三", "", 1, 107, true));
        employees.add(new EnrolledEmployee("304867", "李四", "", 1, 107, true));
        employees.add(new EnrolledEmployee("304878", "王五", "", 1, 107, true));
        employees.add(new EnrolledEmployee("304889", "赵六", "", 1, 107, true));
        employees.add(new EnrolledEmployee("304890", "孙七", "", 1, 107, true));
        
        return employees;
    }
    
    /**
     * 创建模拟考勤数据
     */
    private AttendanceRecordsStatement createMockAttendanceRecords() {
        List<AttendanceRecord> records = new ArrayList<>();
        SimpleDateFormat sdf = new SimpleDateFormat("yyyy-MM-dd HH:mm:ss");
        
        try {
            // 今天的考勤记录
            String today = new SimpleDateFormat("yyyy-MM-dd").format(new Date());
            
            records.add(new AttendanceRecord(107, "304837", AttendanceOperation.IN, 
                sdf.parse(today + " 08:30:15").getTime(), System.currentTimeMillis()));
            records.add(new AttendanceRecord(107, "304843", AttendanceOperation.IN, 
                sdf.parse(today + " 08:35:22").getTime(), System.currentTimeMillis()));
            records.add(new AttendanceRecord(107, "304856", AttendanceOperation.IN, 
                sdf.parse(today + " 08:45:10").getTime(), System.currentTimeMillis()));
            records.add(new AttendanceRecord(107, "304867", AttendanceOperation.IN, 
                sdf.parse(today + " 09:10:20").getTime(), System.currentTimeMillis()));
            records.add(new AttendanceRecord(107, "304878", AttendanceOperation.IN, 
                sdf.parse(today + " 08:55:33").getTime(), System.currentTimeMillis()));
            records.add(new AttendanceRecord(107, "304889", AttendanceOperation.IN, 
                sdf.parse(today + " 09:05:45").getTime(), System.currentTimeMillis()));
            
            // 中午外出记录
            records.add(new AttendanceRecord(107, "304837", AttendanceOperation.OUT, 
                sdf.parse(today + " 12:00:30").getTime(), System.currentTimeMillis()));
            records.add(new AttendanceRecord(107, "304843", AttendanceOperation.OUT, 
                sdf.parse(today + " 12:15:45").getTime(), System.currentTimeMillis()));
            
            // 下午回来记录
            records.add(new AttendanceRecord(107, "304837", AttendanceOperation.IN, 
                sdf.parse(today + " 13:30:15").getTime(), System.currentTimeMillis()));
            records.add(new AttendanceRecord(107, "304843", AttendanceOperation.IN, 
                sdf.parse(today + " 13:45:22").getTime(), System.currentTimeMillis()));
            
            // 下班记录
            records.add(new AttendanceRecord(107, "304856", AttendanceOperation.OUT, 
                sdf.parse(today + " 17:30:15").getTime(), System.currentTimeMillis()));
            records.add(new AttendanceRecord(107, "304867", AttendanceOperation.OUT, 
                sdf.parse(today + " 17:45:30").getTime(), System.currentTimeMillis()));
            
        } catch (Exception e) {
            System.err.println("创建模拟考勤数据时发生错误: " + e.getMessage());
        }
        
        return new AttendanceRecordsStatement(107, System.currentTimeMillis(), System.currentTimeMillis(), records);
    }
    
    /**
     * 获取设备信息
     */
    private Map<String, Object> getDeviceInfo() {
        Map<String, Object> deviceInfo = new HashMap<>();
        deviceInfo.put("deviceName", deviceName);
        deviceInfo.put("model", "nFace102-s");
        deviceInfo.put("algorithm", "ZKFingervx10.0");
        deviceInfo.put("platform", "ZMM510_TFT");
        deviceInfo.put("firmware", "ZMM50-NF-Ver1.0.25");
        deviceInfo.put("ip", "192.168.10.180");
        deviceInfo.put("port", 4370);
        deviceInfo.put("machineNumber", 107);
        deviceInfo.put("mode", "simulation");
        return deviceInfo;
    }
}

