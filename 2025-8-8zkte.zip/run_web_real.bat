@echo off
echo ========================================
echo 考勤机管理系统 - 真实数据版
echo ========================================
echo.
echo 正在启动Web服务器...
echo 使用真实考勤机数据，支持数据库存储
echo.

cd /d "%~dp0"
cd target

echo 启动参数:
echo - 端口: 8080
echo - 数据源: 真实考勤机 (nFace102-s)
echo - 数据库: SQLite (attendance.db)
echo - IP地址: 192.168.10.180
echo.

java -cp "classes;dependency/*" ps.purelogic.zkem4j.web.AttendanceWebServerReal

echo.
echo Web服务器已停止
pause

