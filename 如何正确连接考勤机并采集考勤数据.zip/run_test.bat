@echo off
echo ========================================
echo 中控考勤机测试程序 - 修复版本
echo ========================================
echo.

echo 检查Java环境...
java -version
if %errorlevel% neq 0 (
    echo 错误：未找到Java环境，请先安装Java 8或更高版本
    pause
    exit /b 1
)

echo.
echo 检查Maven环境...
mvn -version
if %errorlevel% neq 0 (
    echo 错误：未找到Maven，请先安装Maven
    pause
    exit /b 1
)

echo.
echo 编译项目...
mvn clean compile
if %errorlevel% neq 0 (
    echo 编译失败，请检查错误信息
    pause
    exit /b 1
)

echo.
echo 打包项目...
mvn package -DskipTests
if %errorlevel% neq 0 (
    echo 打包失败，请检查错误信息
    pause
    exit /b 1
)

echo.
echo 运行考勤机测试...
echo 注意：请确保考勤机IP地址和密码配置正确
echo.

java -cp "target/classes;target/dependency/*" ps.purelogic.zkem4j.AttendanceTest

echo.
echo 测试完成！
pause

