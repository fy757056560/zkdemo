/*
 * 考勤机测试类 - 修复版本
 * 解决TFT类型考勤机数据获取问题
 */
package ps.purelogic.zkem4j;

import java.text.SimpleDateFormat;
import java.util.List;
import java.util.Observable;
import java.util.Observer;
import javax.swing.JFrame;
import ps.purelogic.zkem4j.notifications.AttendanceNotification;
import ps.purelogic.zkem4j.notifications.StatusChangeNotification;

/**
 * 考勤机测试类
 * 使用智能API选择机制，根据设备类型自动选择正确的数据获取方法
 * 
 * @author 修复版本
 */
public class AttendanceTest implements Observer {

    private AttendanceTerminal terminal;

    public AttendanceTest() {
        prepare();
    }

    private void prepare() {
        System.out.println("=== 考勤机连接测试 ===");
        System.out.println("设备型号: nFace102-s");
        System.out.println("指纹算法: ZKFingervx10.0");
        System.out.println("平台信息: ZMM510_TFT");
        System.out.println("固件版本: ZMM50-NF-Ver1.0.25");
        System.out.println("IP地址: 192.168.10.180");
        System.out.println("通讯密码: 202306");
        System.out.println("机号: 107");
        System.out.println();

        // 使用正确的考勤机信息
        AttendanceTerminal aTerminal = new AttendanceTerminal(
            107,                    // 机号
            "nFace102-s",          // 设备名称
            "B",                   // 区块号
            "Base",                // 区块名称
            1,                     // 品牌ID
            "ZKTeco",              // 品牌名称
            "192.168.10.180",      // IP地址
            4370,                  // 端口号
            202306,                // 通讯密码
            0L                     // 最后读取时间戳
        );
        
        aTerminal.addObserver(this);
        this.terminal = aTerminal;

        System.out.println("尝试连接考勤机...");
        aTerminal.connect();

        // 等待连接完成
        try {
            Thread.sleep(3000);
        } catch (InterruptedException e) {
            e.printStackTrace();
        }

        // 获取员工信息
        System.out.println("获取员工信息...");
        List<EnrolledEmployee> employees = aTerminal.readEnrolledEmployees();
        
        if (employees != null && !employees.isEmpty()) {
            System.out.println("员工信息：");
            for (EnrolledEmployee employee : employees) {
                System.out.println("  工号: " + employee.getEnrollmentId() + 
                                 ", 姓名: " + employee.getName() + 
                                 ", 权限: " + employee.getPrivilege() + 
                                 ", 是否启用: " + employee.isEnabled());
            }
            System.out.println("总员工数: " + employees.size());
        } else {
            System.out.println("未获取到员工信息或员工列表为空");
        }

        System.out.println();
        System.out.println("=== 开始获取考勤数据 ===");
        
        // 使用智能方法获取考勤记录
        AttendanceRecordsStatement stmt = aTerminal.readAttendanceRecordsSmart();

        if (stmt != null && stmt.getRecords() != null) {
            SimpleDateFormat format = new SimpleDateFormat("yyyy-MM-dd HH:mm:ss");
            
            System.out.println("考勤数据：");
            System.out.println("序号\t工号\t\t姓名\t\t时间\t\t\t对比方式\t设备名称");
            System.out.println("--------------------------------------------------------------------");
            
            int index = 1;
            for (AttendanceRecord record : stmt.getRecords()) {
                // 查找对应的员工姓名
                String employeeName = "未知";
                if (employees != null) {
                    for (EnrolledEmployee employee : employees) {
                        if (employee.getEnrollmentId().equals(record.getEmployeeNo())) {
                            employeeName = employee.getName();
                            break;
                        }
                    }
                }
                
                // 根据验证方式确定对比方式（这里简化处理）
                String verifyMethod = "指纹"; // 可以根据实际的验证方式字段来确定
                
                System.out.println(index + "\t" + 
                                 record.getEmployeeNo() + "\t\t" + 
                                 employeeName + "\t\t" + 
                                 format.format(record.getAttendanceTime()) + "\t" + 
                                 verifyMethod + "\t\t" + 
                                 "nFace102-s");
                index++;
            }
            
            System.out.println("--------------------------------------------------------------------");
            System.out.println("总考勤记录数: " + stmt.getRecords().size());
        } else {
            System.out.println("未获取到考勤记录或记录列表为空");
        }

        // 断开连接
        System.out.println();
        System.out.println("断开考勤机连接...");
        aTerminal.disconnect();
    }

    public static void main(String[] args) {
        // 创建窗口（SDK要求）
        JFrame frame = new JFrame("考勤机测试");
        frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        frame.setSize(300, 200);
        frame.setVisible(true);

        // 运行测试
        AttendanceTest test = new AttendanceTest();
        
        // 等待一段时间后关闭窗口
        try {
            Thread.sleep(5000);
        } catch (InterruptedException e) {
            e.printStackTrace();
        }
        
        System.out.println("测试完成！");
        System.exit(0);
    }

    @Override
    public void update(Observable o, Object arg) {
        if (arg instanceof StatusChangeNotification) {
            StatusChangeNotification notification = (StatusChangeNotification) arg;
            System.out.println("状态更新: " + notification.getStatus());
        } else if (arg instanceof AttendanceNotification) {
            AttendanceNotification notification = (AttendanceNotification) arg;
            System.out.println("实时考勤: " + notification.getRecord().getEmployeeNo() + 
                             " " + notification.getRecord().getAttendanceTime() + 
                             " " + notification.getRecord().getTerminalId());
        }
    }
}

