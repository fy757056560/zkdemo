@echo off
echo 正在运行考勤机程序，日志将保存到 attendance_log.txt 文件中...
echo 程序运行中，请稍候...

REM 运行JAR文件并将所有输出（包括错误输出）重定向到日志文件
java -jar ZKEM4J-1.0-SNAPSHOT-jar-with-dependencies.jar > attendance_log.txt 2>&1

echo 程序运行完毕，请查看 attendance_log.txt 文件获取完整日志。
pause

