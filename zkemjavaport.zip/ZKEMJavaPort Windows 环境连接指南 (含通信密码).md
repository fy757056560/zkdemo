# ZKEMJavaPort Windows 环境连接指南 (含通信密码)

本指南将详细说明如何在 Windows 环境下使用已修改的 `ZKEMJavaPort` 项目来连接带有通信密码的中控考勤机。该项目基于 `com4j` 库，需要 `zkemkeeper.dll` 支持。

## 1. 前提条件

在开始之前，请确保您的 Windows 环境满足以下条件：

*   **操作系统**: Windows 7 或更高版本 (32位或64位)。
*   **Java 开发工具包 (JDK)**: 推荐使用 JDK 8 或更高版本。请确保已正确配置 `JAVA_HOME` 环境变量并将其添加到 `Path` 中。
*   **Apache Maven**: 用于项目构建和依赖管理。请确保已正确安装并配置环境变量。
*   **`zkemkeeper.dll`**: 这是中控考勤机 SDK 的核心 COM 组件。您需要从考勤机厂商获取此 DLL 文件，并将其注册到您的 Windows 系统中。通常，您可以使用 `regsvr32.exe` 命令进行注册（以管理员身份运行命令提示符）：
    ```bash
    regsvr32 C:\path\to\zkemkeeper.dll
    ```
    请将 `C:\path\to\zkemkeeper.dll` 替换为 `zkemkeeper.dll` 的实际路径。
*   **网络连接**: 您的 Windows 机器需要能够通过网络访问考勤机。

## 2. 文件说明

您将收到以下文件：

*   `ZKEMJavaPort-master_modified_source.zip`: 包含已修改的 `ZKEMJavaPort` 项目的完整源代码。其中 `src/main/java/ps/purelogic/zkem4j/Test.java` 文件已更新，包含了设置考勤机IP、端口、通信密码和机器号的示例代码。

## 3. 项目设置与编译

1.  **解压源代码**: 将 `ZKEMJavaPort-master_modified_source.zip` 解压到您选择的目录，例如 `C:\ZKEMJavaPort-master`。

2.  **处理 `icmp4j` 依赖**: `ZKEMJavaPort` 项目的 `pom.xml` 中包含 `icmp4j` 依赖，该库用于 Ping 操作。在某些 Windows 环境下，`icmp4j` 可能会导致编译或运行时问题。您可以选择：
    *   **推荐**: 移除 `icmp4j` 依赖。打开 `C:\ZKEMJavaPort-master\pom.xml` 文件，找到并删除以下内容：
        ```xml
        <dependency>
            <groupId>sheltekio.javalibs</groupId>
            <artifactId>icmp4j</artifactId>
            <version>1.2</version>
        </dependency>
        ```
        同时，您还需要修改 `src/main/java/ps/purelogic/zkem4j/AttendanceTerminal.java` 文件，将 `pingServer()` 方法中的 `IcmpPingRequest` 和 `IcmpPingUtil` 相关代码注释掉或删除，并直接返回 `true`，例如：
        ```java
        private boolean pingServer() {
            // IcmpPingRequest request = IcmpPingUtil.createIcmpPingRequest();
            // request.setHost(ipAddress);
            // request.setPacketSize(32);
            // request.setTimeout(5000);
            // request.setTtl(1000);
            // return IcmpPingUtil.executePingRequest(request).getSuccessFlag();
            return true; // 假设网络总是可达
        }
        ```
    *   **备选**: 尝试解决 `icmp4j` 问题。这可能需要您手动下载 `icmp4j` 的相关 DLL 文件并将其放置在系统路径中，或者在 Maven 配置中进行更复杂的设置。由于其复杂性和不确定性，不推荐此方法。

3.  **修改考勤机参数**: 打开 `C:\ZKEMJavaPort-master\src\main\java\ps\purelogic\zkem4j\Test.java` 文件。

    *   找到 `prepare()` 方法中的以下行，并根据您的考勤机实际参数进行修改：
        ```java
        String deviceIp = "192.168.10.180";  // 您的考勤机IP
        int devicePort = 4370;               // 您的考勤机端口
        int commPassword = 202306;           // 您的通信密码 (请确保是整数类型)
        int machineNo = 107;                 // 您的考勤机设备号
        ```
        **重要提示**: 考勤机通信密码通常是数字，并且您之前提到最少6位。请确保 `commPassword` 的值与您考勤机上设置的通信密码完全一致。

4.  **编译项目**: 打开命令提示符 (CMD) 或 PowerShell，导航到 `ZKEMJavaPort-master` 项目的根目录 (例如 `cd C:\ZKEMJavaPort-master`)，然后运行 Maven 命令进行编译：
    ```bash
    mvn clean install -DskipTests
    ```
    如果编译成功，您将在 `target` 目录下找到生成的 JAR 文件 (例如 `ZKEM4J-1.0-SNAPSHOT.jar`)。

## 4. 运行测试

编译成功后，您可以通过以下方式运行 `Test.java` 中的示例代码：

1.  **通过 Maven 运行**: 在 `ZKEMJavaPort-master` 项目的根目录下，运行：
    ```bash
    mvn exec:java -Dexec.mainClass="ps.purelogic.zkem4j.Test"
    ```
2.  **直接运行 JAR 文件**: 如果您想直接运行生成的 JAR 文件，需要确保 `com4j` 相关的依赖（包括 `com4j.dll` 和 `com4j.jar`）在运行时环境中可用。最简单的方法是将 `com4j.jar` 和 `ZKEM4J-1.0-SNAPSHOT.jar` 放在同一个目录下，并确保 `com4j.dll` 位于系统 PATH 环境变量指定的路径中，或者在运行命令时通过 `-Djava.library.path` 指定其路径。
    ```bash
    java -jar target\ZKEM4J-1.0-SNAPSHOT.jar
    ```
    或者，如果需要指定 `com4j.dll` 路径：
    ```bash
    java -Djava.library.path="C:\path\to\com4j_dll" -jar target\ZKEM4J-1.0-SNAPSHOT.jar
    ```
    请将 `C:\path\to\com4j_dll` 替换为 `com4j.dll` 的实际路径。

## 5. 故障排除

*   **`java.lang.UnsatisfiedLinkError`**: 这通常意味着 Java 无法找到或加载 `zkemkeeper.dll` 或 `com4j.dll`。请确保：
    *   DLL 文件已正确注册。
    *   DLL 文件位于系统 PATH 环境变量指定的路径中，或者您在运行 Java 命令时通过 `-Djava.library.path` 指定了正确的路径。
    *   DLL 文件的位数 (32位/64位) 与您的 Java 运行时环境的位数匹配。
*   **连接失败**: 如果程序报告连接失败，请检查：
    *   考勤机是否已开机并连接到网络。
    *   考勤机 IP 地址和端口是否正确。
    *   考勤机通信密码是否与代码中设置的 `commPassword` 一致。
    *   Windows 防火墙是否阻止了 Java 程序的网络连接。
    *   考勤机设备号是否正确。
*   **`icmp4j` 编译或运行时错误**: 如果您没有移除 `icmp4j` 依赖，并且遇到相关错误，请尝试移除该依赖并修改 `pingServer()` 方法，如第 3 节所述。

希望这份详细的指南能帮助您成功连接中控考勤机！如果您在 Windows 环境下操作过程中遇到任何问题，请随时向我反馈。

