@echo off
echo 启动修复后的考勤机程序...
echo.
echo 请确保：
echo 1. 考勤机IP地址为：192.168.10.180
echo 2. 考勤机端口为：4370
echo 3. 通讯密码为：202306
echo 4. 网络连接正常
echo.
pause
echo.
echo 正在连接考勤机并获取数据...
java -cp 修复后的考勤机程序-完整版.jar ps.purelogic.zkem4j.Test
echo.
echo 程序执行完成。
pause

