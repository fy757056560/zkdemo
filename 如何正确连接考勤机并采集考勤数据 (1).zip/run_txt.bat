@echo off
echo 考勤机数据采集程序 - TXT文件输出
echo =====================================
echo.

java -cp "target/classes;target/dependency/*" ps.purelogic.zkem4j.AttendanceTestNew txt

echo.
echo 数据已导出到TXT文件！
echo 请查看当前目录下的 考勤数据_*.txt 文件
echo.
pause

