@echo off
echo 考勤机数据采集程序 - Web界面
echo =====================================
echo.

echo 启动Web服务器...
echo 访问地址: http://localhost:8080
echo 按 Ctrl+C 停止服务器
echo.

java -cp "target/classes;target/dependency/*" ps.purelogic.zkem4j.web.AttendanceWebServer 8080

pause

