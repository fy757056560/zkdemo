@echo off
echo 考勤机数据采集程序 - 控制台版本
echo =====================================
echo.

REM 检查Java环境
java -version >nul 2>&1
if %errorlevel% neq 0 (
    echo 错误: 未找到Java运行环境，请先安装Java 8或更高版本
    pause
    exit /b 1
)

echo 启动程序...
echo.

REM 运行程序 - 控制台输出
java -cp "target/classes;target/dependency/*" ps.purelogic.zkem4j.AttendanceTestNew console

echo.
echo 程序执行完成！
echo.
echo 其他运行方式:
echo   run_txt.bat    - 输出到TXT文件
echo   run_excel.bat  - 输出到Excel文件
echo   run_web.bat    - 启动Web界面
echo.
pause

