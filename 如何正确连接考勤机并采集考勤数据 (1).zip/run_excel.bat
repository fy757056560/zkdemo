@echo off
echo 考勤机数据采集程序 - Excel文件输出
echo =====================================
echo.

java -cp "target/classes;target/dependency/*" ps.purelogic.zkem4j.AttendanceTestNew excel

echo.
echo 数据已导出到Excel文件！
echo 请查看当前目录下的 考勤数据_*.xlsx 文件
echo.
pause

